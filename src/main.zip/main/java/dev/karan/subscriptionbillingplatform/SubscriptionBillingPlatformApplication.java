package dev.karan.subscriptionbillingplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
public class SubscriptionBillingPlatformApplication {

    public static void main(String[] args) {
        SpringApplication.run(SubscriptionBillingPlatformApplication.class, args);
    }

}
