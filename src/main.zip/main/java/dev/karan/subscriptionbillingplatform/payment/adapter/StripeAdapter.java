package dev.karan.subscriptionbillingplatform.payment.adapter;

import dev.karan.subscriptionbillingplatform.payment.enums.PaymentGateway;
import dev.karan.subscriptionbillingplatform.payment.enums.PaymentStatus;
import dev.karan.subscriptionbillingplatform.payment.gateway.PaymentGatewayRequest;
import dev.karan.subscriptionbillingplatform.payment.gateway.PaymentGatewayResponse;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class StripeAdapter implements PaymentGatewayAdapter{

    @Override
    public PaymentGatewayResponse createPayment(PaymentGatewayRequest request) {
        String gatewayOrderId =
                "STRIPE-" + UUID.randomUUID().toString().substring(0,8);
        String paymentUrl =
                "https://checkout.stripe.com/pay/" + gatewayOrderId;
        return PaymentGatewayResponse.builder()
                .gatewayOrderId(gatewayOrderId)
                .paymentUrl(paymentUrl)
                .status(PaymentStatus.PENDING)
                .build();
    }

    @Override
    public PaymentGateway getSupportedGateway() {
        return PaymentGateway.STRIPE;
    }
}
